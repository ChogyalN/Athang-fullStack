package com.jdbcathang01.athangfullstack01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AthangFullStackApplication {

	public static void main(String[] args) {
		SpringApplication.run(AthangFullStackApplication.class, args);
	}

}
