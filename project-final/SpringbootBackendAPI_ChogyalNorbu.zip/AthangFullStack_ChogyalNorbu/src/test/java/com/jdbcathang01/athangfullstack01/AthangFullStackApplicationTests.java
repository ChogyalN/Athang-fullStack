package com.jdbcathang01.athangfullstack01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AthangFullStackApplicationTests {

	@Test
	void contextLoads() {
	}

}
